<?php
/**
 * Created by PhpStorm.
 * User: novichkov
 * Date: 11.12.14
 * Time: 19:51
 */
require_once('config.php');
if(!isset($_POST['export']))
{
    echo ('
    <!DOCTYPE html>
    <html>
    <head>
        <link rel="stylesheet" type="text/css" href="'.SITE_DIR.'css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="'.SITE_DIR.'css/style.css">
    </head>
    <body>
    ');
}
session_start();
if(!$_SESSION['login'])
{
    echo ('
    <br><br><br><br><br><br><br>
    <div class="row">
        <form name="login" action="controller.php" method="post">
        <div class="col-xs-offset-4 col-xs-4">
            <div class="panel panel-warning">
                <div class="panel-heading text-center">
                    <h4 class="panel-title">Log In</h4>
                </div>
                <div class="panel-body">
                    <div class="form-group">
                        <label>
                            Login
                        </label>
                        <input type="text" name="login" class="form-control">
                    </div>
                    <div class="form-group">
                        <label>
                            Password
                        </label>
                        <input type="password" name="password"  class="form-control">
                    </div>
                </div>
                <div class="panel-footer">
                    <input type="submit" class="btn btn-success" name="login_btn" value="login">
                    <a href="' . SITE_DIR . '" class="btn btn-default">Cancel</a>
                </div>
            </div>
        </div>
        </form>
    </div>
    ');
}
if($_SESSION['login'] == 'admin')
{

    $con=mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
    $query = 'SELECT * FROM detox_users ORDER BY sdate';
    $res = mysqli_query($con, $query);
    if(isset($_POST['export']))
    {
        $string = 'firstname;email;date' . "\n";

        while($row = $res->fetch_assoc())
        {
            $string .= $row['firstname'] . ';' . $row['email'] . ';' . date('M d, Y H:i', strtotime($row['sdate'])) . "\n";

        }
        header('Content-type:application/csv');
        header('Content-Disposition:attachment;filename=subscribers.csv');
        echo $string;
        exit;
    }
    echo '
    <div class="row">
        <div class="col-md-8 col-sm-10">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">21 Days Detox Program Subscribers</h3>
                </div>
                <div class="panel-body">
                <div class="table">
                <table class="table table-bordered" id="data_table">
                    <thead>
                        <tr>
                            <th>Firstname</th>
                            <th>Email</th>
                            <th>Sign Up Date</th>
                        </tr>
                    </thead>
                    <tbody>
    ';
    while($row = $res->fetch_assoc())
    {
         echo '
                        <tr>
                            <td>
                                ' . $row['firstname'] . '
                            </td>
                            <td>
                                ' . $row['email'] . '
                            </td>
                            <td>
                                ' . date('M d, Y H:i', strtotime($row['sdate'])) . '
                            </td>
                        </tr>
         ';
    }
    echo '
                    </tbody>
                </table>
                </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <form action="" method="post">
            <button class="btn btn-lg" type="submit" name="export"><i class="glyphicon glyphicon-download-alt"></i> Export in CSV<button>
        </form>
    </div>
    ';
}


?>
</body>
</html>